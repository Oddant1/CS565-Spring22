/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server.transaction;

/**
 * Creates new transaction workers that communicate with a given transaction on
 * the client
 *
 * @author anthony
 */
public class TransactionManager 
{    
    // Spawns a worker
    public void createTransaction()
    {
        
    }
}
